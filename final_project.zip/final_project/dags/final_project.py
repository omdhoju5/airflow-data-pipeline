from datetime import datetime, timedelta
import pendulum
import os
from airflow.decorators import dag
from airflow.operators.dummy_operator import DummyOperator
from final_project_operators.stage_redshift import StageToRedshiftOperator
from final_project_operators.load_fact import LoadFactOperator
from final_project_operators.load_dimension import LoadDimensionOperator
from final_project_operators.data_quality import DataQualityOperator
from udacity.common.final_project_sql_statements import *
from airflow.operators.postgres_operator import PostgresOperator


default_args = {
    'owner': 'udacity',
    'start_date': pendulum.now(),
    'catchup':False,
    'retries': 3,
    "retry_delay": timedelta(minutes=5),
    'email_on_retry': False,
    'depends_on_past': False,
}

@dag(
    default_args=default_args,
    description='Load and transform data in Redshift with Airflow',
    schedule_interval='0 * * * *'
)
def final_project():

    begin_execution = DummyOperator( task_id="Begin_execution")

    # Create stage_events_table if not exists
    create_staging_events_table = PostgresOperator(
        task_id="staging_events",
        postgres_conn_id="redshift",
        sql=SqlQueries.staging_events_table_create
    )

    ## Copy events data from s3 to redshift 
    stage_events_to_redshift = StageToRedshiftOperator(
        task_id='Stage_events',
        redshift_conn_id='redshift',
        aws_credentials_id='aws_credentials',
        table='staging_events',
        s3_bucket='stedi-udaci',
        s3_key='sparkify/log_data/2018/11' 
    )

    begin_execution >> create_staging_events_table >> stage_events_to_redshift

    # Create stage_songs_table if not exists
    create_staging_songs_table = PostgresOperator(
        task_id="staging_songs",
        postgres_conn_id="redshift",
        sql=SqlQueries.staging_songs_table_create
    )

    ## Copy songs data from s3 to redshift 
    stage_songs_to_redshift = StageToRedshiftOperator(
        task_id='Stage_songs',
        redshift_conn_id='redshift',
        aws_credentials_id='aws_credentials',
        table='staging_songs',
        s3_bucket='stedi-udaci',
        s3_key='sparkify/song_data' 
    )

    begin_execution >> create_staging_songs_table >> stage_songs_to_redshift

    ## Load the data to create fact table
    load_songplays_table = LoadFactOperator(
        task_id='Load_songplays_fact_table',
        redshift_conn_id='redshift',
        target_table='songplays',
        sql=SqlQueries.songplay_table_insert
    )

    stage_events_to_redshift >> load_songplays_table
    stage_songs_to_redshift >> load_songplays_table


    load_user_dimension_table = LoadDimensionOperator(
        task_id='Load_user_dim_table',
        redshift_conn_id='redshift',
        target_table='users',
        sql=SqlQueries.user_table_insert
    )

    load_songplays_table >> load_user_dimension_table

    load_song_dimension_table = LoadDimensionOperator(
        task_id='Load_song_dim_table',
        redshift_conn_id='redshift',
        target_table='songs',
        sql=SqlQueries.song_table_insert
    )

    load_songplays_table >> load_song_dimension_table

    load_artist_dimension_table = LoadDimensionOperator(
        task_id='Load_artist_dim_table',
        redshift_conn_id='redshift',
        target_table='artists',
        sql=SqlQueries.artist_table_insert
    )

    load_songplays_table >> load_artist_dimension_table

    load_time_dimension_table = LoadDimensionOperator(
        task_id='Load_time_dim_table',
        redshift_conn_id='redshift',
        target_table='time',
        sql=SqlQueries.time_table_insert
    )

    load_songplays_table >> load_time_dimension_table

    run_quality_checks = DataQualityOperator(
        task_id='Run_data_quality_checks',
        redshift_conn_id='redshift',
        table='songplays',
        condition='songplay_id is null',
        expected_result_count=0
    )

    load_time_dimension_table >> run_quality_checks
    load_user_dimension_table >> run_quality_checks
    load_song_dimension_table >> run_quality_checks
    load_artist_dimension_table >> run_quality_checks
    load_time_dimension_table >> run_quality_checks

    end_execution = DummyOperator( task_id="End_execution")
    run_quality_checks >> end_execution

final_project_dag = final_project()