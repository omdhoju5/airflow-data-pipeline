from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class LoadDimensionOperator(BaseOperator):

    ui_color = '#80BD9E'
    dim_sql_template = """ 
        DROP TABLE IF EXISTS {target_table};
        CREATE TABLE {target_table} AS
        {select}
    """

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 target_table="",
                 sql="",
                 *args, **kwargs):

        super(LoadDimensionOperator, self).__init__(*args, **kwargs)
        self.redshift_conn_id = redshift_conn_id
        self.target_table = target_table
        self.sql = sql

    def execute(self, context):
        self.log.info('Loading the data on to {}'.format(self.target_table))
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)

        date = context["logical_date"]
        self.log.info("Execution date for loading dim table {}, {} and {}".format(self.target_table, date.year, date.month))
        redshift.run(self.dim_sql_template.format(target_table= self.target_table, select = self.sql))
