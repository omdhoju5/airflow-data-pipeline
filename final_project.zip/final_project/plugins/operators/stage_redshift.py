from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.contrib.hooks.aws_hook import AwsHook

class StageToRedshiftOperator(BaseOperator):
    ui_color = '#358140'
    template_fields = ("s3_key",)
    copy_sql = """
        COPY {}
        FROM '{}'
        ACCESS_KEY_ID '{}'
        SECRET_ACCESS_KEY '{}'
        FORMAT AS JSON '{}'
    """


    @apply_defaults
    def __init__(self,
                redshift_conn_id="",
                aws_credentials_id="",
                table="",
                s3_bucket="",
                s3_key="",
                backfill_data=False,
                json_path='auto ignorecase',
                *args, **kwargs):

        super(StageToRedshiftOperator, self).__init__(*args, **kwargs)
        self.table = table
        self.redshift_conn_id = redshift_conn_id
        self.s3_bucket = s3_bucket
        self.s3_key = s3_key
        self.aws_credentials_id = aws_credentials_id
        self.backfill_data = backfill_data
        self.json_path = json_path

    def execute(self, context):
        self.log.info('Staging {}'.format(self.table))
        aws_hook = AwsHook(self.aws_credentials_id)
        credentials = aws_hook.get_credentials()
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)
        date = context["logical_date"]
        self.log.info("Execution date {} and {}".format(date.year, date.month))

        self.log.info("Clearing data from destination Redshift table {}".format(self.table))
        redshift.run("DELETE FROM {}".format(self.table))

        self.log.info("Backfill_data: {}".format(self.backfill_data))
        s3_bucket_key = "s3://{}/{}".format(self.s3_bucket, self.s3_key)
        if self.backfill_data:
            s3_path = s3_bucket_key + '/' + str(date.year) + '/' + str(
                date.month)
        else:
            s3_path = s3_bucket_key
        self.log.info("S3 path: {}".format(s3_path))

        self.log.info("Copying data from S3 to Redshift")
        
        formatted_sql = StageToRedshiftOperator.copy_sql.format(
            self.table,
            s3_path,
            credentials.access_key,
            credentials.secret_key,
            self.json_path
        )
        
        self.log.info(
            "SQL Statement Executing on Redshift: {}".format(formatted_sql))
        redshift.run(formatted_sql)





