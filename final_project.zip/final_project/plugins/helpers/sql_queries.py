class SqlQueries:
    songplay_table_insert = ("""
        SELECT
                md5(events.sessionId || events.start_time) songplay_id,
                events.start_time, 
                events.userId, 
                events.level, 
                songs.song_id, 
                songs.artist_id, 
                events.sessionId, 
                events.location, 
                events.userAgent
                FROM (SELECT TIMESTAMP 'epoch' + ts/1000 * interval '1 second' AS start_time, *
            FROM staging_events
            WHERE page='NextSong') events
            LEFT JOIN staging_songs songs
            ON events.song = songs.title
                AND events.artist = songs.artist_name
                AND events.length = songs.duration
    """)

    user_table_insert = ("""
        SELECT distinct userId, firstName, lastName, gender, level
        FROM staging_events
        WHERE page='NextSong'
    """)

    song_table_insert = ("""
        SELECT distinct song_id, title, artist_id, year, duration
        FROM staging_songs
    """)

    artist_table_insert = ("""
        SELECT distinct artist_id, artist_name, artist_location, artist_latitude, artist_longitude
        FROM staging_songs
    """)

    time_table_insert = ("""
        SELECT DISTINCT start_time, extract(hour from start_time) as hour, extract(day from start_time) as day, extract(week from start_time) as week, 
               extract(month from start_time) as month, extract(year from start_time) as year, extract(dayofweek from start_time) as dayofweek
        FROM songplays
    """)

    staging_events_table_create = ("""
        CREATE TABLE IF NOT EXISTS staging_events (
        artist VARCHAR,
        auth VARCHAR NOT NULL,
        firstName VARCHAR,
        gender VARCHAR(50),
        itemInSession INTEGER,
        lastName VARCHAR,
        length NUMERIC,
        level VARCHAR NOT NULL,
        location VARCHAR,
        method VARCHAR(50) NOT NULL,
        page VARCHAR NOT NULL,
        registration NUMERIC,
        "sessionId" INTEGER,
        song VARCHAR,
        status INTEGER,
        ts BIGINT,
        userAgent VARCHAR,
        userId INTEGER )
    """)

    staging_songs_table_create = ("""
        CREATE TABLE IF NOT EXISTS staging_songs (
        artist_id VARCHAR NOT NULL,
        artist_latitude NUMERIC,
        artist_location VARCHAR,
        artist_longitude NUMERIC,
        artist_name VARCHAR,
        duration NUMERIC,
        num_songs INTEGER,
        song_id VARCHAR NOT NULL,
        title VARCHAR NOT NULL, 
        year INTEGER )
    """)